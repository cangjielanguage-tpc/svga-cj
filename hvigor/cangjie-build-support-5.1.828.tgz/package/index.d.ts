import type { Module, Project } from '@ohos/hvigor';
import type { HapPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hap-plugin';
import type { HarPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/har-plugin';
import type { HspPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hsp-plugin';
import type { AppPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/app-plugin';
import { AbstractHapModulePlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/common/abstract-hap-module-plugin';
import { AbstractHarModulePlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/common/abstract-har-module-plugin';
/**
 * 生成或删除仓颉schema
 */
export declare function handleCangjieSchema(): void;
/**
 * register cangjie app task
 * @param project 项目
 * @param appPlugin app级别的接口和任务的plugin
 */
export declare function registerCangjieAppTask(project: Project, appPlugin: AppPlugin): AppPlugin;
/**
 * register cangjie hap task
 * @param module 模块
 * @param abstractHapPlugin hap级别的接口和任务的plugin
 */
export declare function registerCangjieHapTask(module: Module, abstractHapPlugin: AbstractHapModulePlugin): HapPlugin;
/**
 * register cangjie hsp task
 * @param module 模块
 * @param hspPlugin hsp级别的接口和任务的plugin
 */
export declare function registerCangjieHspTask(module: Module, hspPlugin: HspPlugin): HspPlugin;
/**
 * register cangjie har task
 * @param module 模块
 * @param abstractHarPlugin har级别的接口和任务的plugin
 */
export declare function registerCangjieHarTask(module: Module, abstractHarPlugin: AbstractHarModulePlugin): HarPlugin;
/**
 * Stage app plugin
 *
 * @param module hvigorProject
 */
export declare const appTasks: (module: Project) => AppPlugin;
/**
 * Stage hap plugin
 *
 * @param module hvigorModule
 */
export declare const hapTasks: (module: Module) => HapPlugin;
/**
 * Stage har plugin
 *
 * @param module hvigorModule
 */
export declare const harTasks: (module: Module) => HarPlugin;
/**
 * Stage hsp plugin
 *
 * @param module hvigorModule
 */
export declare const hspTasks: (module: Module) => HspPlugin;
