/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import { OhosHapTask } from '@ohos/hvigor-ohos-plugin/src/tasks/task/ohos-hap-task';
import type { TaskDetails } from '@ohos/hvigor';
import type { CangjieOpt } from '@ohos/hvigor-ohos-plugin/src/options/build/build-opt';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { SdkCangjieComponent } from '../sdk/sdk-cangjie-component';
import { CompileAppTypeEnum } from '../enums/compile-app-type-enum';
/**
 * cangjie task base class
 *
 * @since 2024/1/6
 */
export declare abstract class BaseCangjieTask extends OhosHapTask {
    protected cjSource: string;
    protected cangjieOption?: CangjieOpt;
    protected cjpmTomlPath: string;
    protected sdkCangjieComponent?: SdkCangjieComponent;
    protected abiFilters: string[];
    private baseLogger;
    protected constructor(targetService: TargetTaskService, taskDetails: TaskDetails);
    taskShouldDo(): boolean;
    /**
     * Initializing the Cangjie SDK Path
     * @protected
     */
    protected initCangjieSdk(): void;
    protected processCjos(srcPath: string, destPath: string): Promise<void>;
    protected initCjSourceDir(cangjieOptionPath: string): void;
    protected copyUnitTests(ohosLibPath: string | undefined, destPath: string, unitTestPackageName: string): Promise<void>;
    protected getAppJson5Path(): string;
    protected getCompileAppType(): CompileAppTypeEnum;
}
