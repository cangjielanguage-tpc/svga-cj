import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { AbstractGenerateCangjieResource } from './abstract-generate-cangjie-resource';
/**
 * generate cangjie resource
 *
 * @since 2024/1/6
 */
export declare class GenerateCangjieResource extends AbstractGenerateCangjieResource {
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
}
