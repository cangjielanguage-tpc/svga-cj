import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { BaseCangjieTask } from './base-cangjie-task';
import { FileSet, type TaskDetails, TaskInputValue } from '@ohos/hvigor';
/**
 * abstract generate cangjie resource
 *
 * @since 2024/1/6
 */
export declare abstract class AbstractGenerateCangjieResource extends BaseCangjieTask {
    private agcrLogger;
    protected constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    declareInputFiles(): FileSet;
    declareInputs(): Map<string, TaskInputValue>;
    protected doTaskAction(): void;
    protected isDependHarModule(): boolean;
    protected generateAbilityRegisters(packageName: string): void;
    protected generateAbilityStageRegisters(packageName: string): void;
    private readTomlContent;
    private readTomlName;
}
