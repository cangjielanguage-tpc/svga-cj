import { BaseCangjieTask } from '../base-cangjie-task';
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * generate toml dependencies
 * No comparison is performed. The original dependency is deleted, and the new dependency is added.
 * Analyze whether it is source code dependency or SO dependency.
 * Use the existing interface of the Hvigor to obtain the local dependency and determine whether the dependency is the
 * source code folder or so+cjo.
 *
 * @since 2024/7/29
 */
export declare class GenerateTomlDependencies extends BaseCangjieTask {
    private gtdLogger;
    private oldDependencies;
    private newDependencies;
    private readonly _isOhpmDependency;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    /**
     * 将oh-package.json5的依赖解析成key、依赖模式（本地、har/远程）、路径[]格式
     * har/远程要识别是arm64-v8a(aarch64-linux-ohos)、x86_64(待确认)
     * 判断依赖是否仓颉：源码文件夹、so+cjo
     */
    private analyzedDependencies;
    private analyzedPackDependsDepends;
    private writeOldDependFile;
    private addNewDepends;
    private doAddNewDepends;
    private removeOldDepends;
    private doRemoveOldDepends;
    private analyzedPackDepends;
    private analyzedSourceDepends;
    private collectPathOptions;
    private jsonToMap;
    private isOhpmDependency;
    private removeSamePaths;
    private hasSamePaths;
    private areSamePath;
    /**
     * 在工程sync的时候，在.idea/.deveco/cangjie目录下生成syscap_api_config.json文件，
     * 编译时透传给cjc，用于对APILevel和Syscap检查
     */
    private updateSysCapApiConfigs;
    private getDeviceSysCap;
}
export declare enum DependType {
    LOCAL_SOURCE = "local_source",
    HAR_PACK = "har_pack"
}
export interface CjDependency {
    name: string;
    version: string;
    tomlName: string;
    dependType: DependType;
    targetDepends: TargetDepend[];
    localDependPaths: string[];
}
export interface TargetDepend {
    dependPaths: string[];
    targetOs: string;
}
