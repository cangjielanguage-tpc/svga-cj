/**
 * generate cangjie schema json file
 *
 * @since 2025/3/9
 */
export declare class GenerateCangjieSchema {
    private static instance;
    private geCjSchemaLogger;
    private readonly ideaConfigPath;
    private constructor();
    static getInstance(ideaConfigPath: string, isCangjiePluginEnabled?: boolean): GenerateCangjieSchema;
    /**
     * delete schema
     */
    deleteSchema(): void;
    /**
     * replace schema
     */
    replaceSchema(): void;
    private addValidator;
    private initUpdateContent;
    private generateCangjieSchema;
    private addProperty;
    private getProjectSchema;
    private getHarSchema;
    private getModuleSchema;
}
