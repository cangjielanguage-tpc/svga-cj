/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { AbstractCompileCangjie } from './abstract-compile-cangjie';
/**
 * compile cangjie task
 *
 * @since 2024/1/6
 */
export declare class CompileCangjie extends AbstractCompileCangjie {
    constructor(taskService: TargetTaskService);
}
