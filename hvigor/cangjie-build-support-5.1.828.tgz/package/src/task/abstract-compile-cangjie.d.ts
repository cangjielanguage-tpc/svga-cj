/// <reference types="node" />
/// <reference types="node" />
import { type TaskDetails } from '@ohos/hvigor';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { type SpawnSyncOptions } from 'child_process';
import { BaseCangjieTask } from './base-cangjie-task';
import { CangjiePathImpl } from '../common/cangjie-path-impl';
/**
 * compile cangjie task
 *
 * @since 2024/1/6
 */
export declare class AbstractCompileCangjie extends BaseCangjieTask {
    private accLogger;
    private readonly srcFilterHarPaths;
    private readonly binFilterHarPaths;
    private compileAppType;
    private asanEnabled;
    constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    protected checkDependencies(): void;
    protected getCjpmProcessEnv(): NodeJS.ProcessEnv;
    protected getCjpmBuildOptions(cmdEnv: NodeJS.ProcessEnv): SpawnSyncOptions;
    /**
     * Execute Cangjie compilation.
     * @returns {Promise<void>}
     * @protected
     */
    protected executeCangjieCompile(): Promise<void>;
    /**
     * Copying Cangjie Compiled Products to the Target Directory
     * @protected
     */
    protected copyResultFile(cangjiePathImpl: CangjiePathImpl, dependsEnv: any, tomlName: string): Promise<void>;
    protected getGitPath(): string;
    protected getMacSdkRoot(): string;
    protected configDependsEnv(cangjiePathImpl: CangjiePathImpl): any;
    protected copyDemandLibsCommon(cangjiePathImpl: CangjiePathImpl, tomlName: string, moduleConfigTomlName: string): Promise<void>;
    private doCopyLibsCompatible;
    private getFilterMsgs;
    private generateWarnMsg;
    private hasLibs;
    private initFilterDependPaths;
    private scanByteCodeHar;
    private getCpus;
    private doCangjieCompile;
    private addTestArgs;
    private getTestCmds;
    private addCjpmCommonArgs;
    private generateDepList;
    private collectDepList;
    private collectSrcDependencies;
    private copyDemandBinLibs;
    private doCopyOneFile;
    private copyDemandBinLibsLegacy;
    private copyDemandStdLibsLegacy;
    private collectDeps;
    private copyDemandStdLibs;
    private addSourceDepend;
    private addStdDepends;
    private addDependCppLibs;
    private configLocalModulesEnv;
    private copyDemandDependLis;
}
