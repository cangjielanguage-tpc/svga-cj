import { ModulePathInfoIml } from '@ohos/hvigor-ohos-plugin/src/common/iml/module-path-info-iml';
import { SdkCangjieComponent } from '../sdk/sdk-cangjie-component';
import { CangjieCommonPath } from './cangjie-common-path';
/**
 * Cangjie Path Info
 *
 * @since 2024/8/1
 */
export declare class CangjiePathImpl extends CangjieCommonPath {
    private readonly _sdkComponent;
    private implLogger;
    constructor(targetName: string, modulePathInfo: ModulePathInfoIml, abi: string, sdkComponent: SdkCangjieComponent);
    getRuntimeOhosPathByAbi(): string;
    getOhosLibsPathByAbi(): string;
    getKitLibsPathByAbi(): string;
    getOpensslPathByAbi(): string;
    getAsanRuntimeLibsPathByAbi(): string;
    getBuildEnvByAbi(tpcPath: string): any;
    getTpcEnvPathByAbi(tpcPath: string): any;
    getOtherConfigEnvs(): any;
    getWrapperMockPathByAbi(): string;
    getWrapperDiffPathByAbi(): string;
    getApiMockPathByAbi(): string;
    getApiCompatiblePathByAbi(): string;
    getRuntimeCompatibilityPathByAbi(): string;
    getRuntimeMockPathByAbi(): string;
}
