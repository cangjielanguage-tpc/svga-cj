/**
 * cangjie build dir consts
 *
 * @since 2024/8/1
 */
export declare class CjBuildDirConst {
    static readonly CJ: string;
    static readonly CJ_BUILD: string;
    static readonly CJ_LIBS: string;
    static readonly COMPILELIBS: string;
    static readonly RELEASE: string;
    static readonly OHOS: string;
    static readonly RUNTIME: string;
    static readonly CJPM_HISTORY: string;
    static readonly BIN_LIBS: string;
    static readonly UNIT_TEST_BIN: string;
    static readonly BUILD_LOG: string;
}
