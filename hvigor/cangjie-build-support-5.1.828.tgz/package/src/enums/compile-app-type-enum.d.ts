/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
export declare enum CompileAppTypeEnum {
    COMPATIBLE_LTE_18 = "COMPATIBLE_LTE_18",
    COMPATIBLE_GT_18 = "COMPATIBLE_GT_18",
    NORMAL_APP = "NORMAL_APP"
}
