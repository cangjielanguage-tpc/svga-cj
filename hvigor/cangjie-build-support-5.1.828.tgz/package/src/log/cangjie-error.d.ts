import { CangjieErrorInfo, ErrorInfoId, MatchOptions, MoreInfo } from './cangjie-types';
/**
 * cangjie的报错
 */
export declare class CangjieError {
    private static readonly validFields;
    protected readonly _errorJsonPaths: string[];
    protected _timestamp: Date;
    protected _id: string | undefined;
    protected _message: string | undefined;
    protected _solutions: string[] | undefined;
    protected _moreInfo: MoreInfo | undefined;
    protected _code: string | undefined;
    protected _checkMessage: string | undefined;
    protected _stack: string | undefined;
    protected _errorInfo: (CangjieErrorInfo & ErrorInfoId) | undefined;
    private readonly _originMessage;
    private readonly _originSolutions;
    private readonly _matchOptions;
    constructor(errorJsonPaths: string[], matchOptions: MatchOptions);
    get originMessage(): string | undefined;
    get originSolutions(): string[] | undefined;
    get timestamp(): Date;
    get errorJsonPaths(): string[];
    get id(): string | undefined;
    get message(): string | undefined;
    get solutions(): string[] | undefined;
    get moreInfo(): MoreInfo | undefined;
    get code(): string | undefined;
    get stack(): string | undefined;
    get checkMessage(): string | undefined;
    get errorInfo(): (CangjieErrorInfo & ErrorInfoId) | undefined;
    set id(value: string | undefined);
    set message(value: string | undefined);
    set solutions(value: string[] | undefined);
    set moreInfo(value: MoreInfo | undefined);
    set code(value: string | undefined);
    set stack(value: string | undefined);
    set checkMessage(value: string | undefined);
    formatMessage(...args: unknown[]): void;
    formatSolutions(index: number, ...args: unknown[]): void;
    /**
     * 是否从json文件中匹配到错误信息
     * @returns {boolean}
     */
    isMatchSuccess(): boolean;
    findErrorInfo(): (CangjieErrorInfo & ErrorInfoId) | undefined;
    /**
     * 查找错误信息
     */
    private match;
    /**
     * 通过field字段匹配错误信息
     */
    private matchByField;
    /**
     * 通过标识匹配错误信息
     */
    private matchById;
    private putIdIntoErrorInfo;
    /**
     * 获取json文件对象
     */
    private getErrorInfoJson;
    private getJsonObj;
}
