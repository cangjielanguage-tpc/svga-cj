import { MoreInfo, TCangjieErrorInfo } from './cangjie-types';
/**
 * cangjie的错误信息描述类。
 * 提供数据的输入、校验、获取。
 */
export declare class CangjieErrorDetail {
    private readonly code;
    private readonly description;
    private readonly cause;
    private readonly position;
    private readonly solutions;
    private readonly moreInfo?;
    constructor(errorInfo?: TCangjieErrorInfo);
    getCode(): string;
    getDescription(): string;
    getCause(): string;
    getPosition(): string;
    getSolutions(): string[];
    getMoreInfo(): MoreInfo | undefined;
    /**
     * 校验HvigorErrorInfo数据是否合法
     * @returns
     */
    checkInfo(): boolean;
    /**
     * 校验错误码的8位数字组成的字符串
     * @returns
     */
    private checkCode;
    /**
     * 校验错误原因是否存在
     * @returns
     */
    private checkCause;
}
