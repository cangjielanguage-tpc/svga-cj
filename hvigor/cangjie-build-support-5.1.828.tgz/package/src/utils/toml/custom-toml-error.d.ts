export default class CustomTomlError extends Error {
    errorLine: number;
    errorColumn: number;
    errorCodeBlock: string;
    constructor(message: string, tomlContent: string, startPosition: number);
}
