export declare function getNewlineIndex(str: string, startPos?: number, endPos?: number): number;
export declare function skipComment(str: string, position: number): number;
export declare function skipVoidChar(str: string, positionParam: number, notSkipNewLines?: boolean): number;
export declare function skipUnusedCharacters(str: string, positionParam: number, separator: string, endCharacter?: string, notSkipNewLines?: boolean): number;
export declare function getStringEnd(str: string, seekPositionParam: number): number;
export declare function removeCommentTrimEnd(str: string, startPosition: number, endPosition: number, allowNewLines?: boolean): [string, number];
export declare function isNewLineOrSpace(lineContent: string): boolean;
export declare function isEmpty(str: string): boolean;
export declare function getLineColFromPos(string: string, startPos: number): [number, number];
