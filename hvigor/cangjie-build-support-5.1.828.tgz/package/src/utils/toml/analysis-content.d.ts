import CustomTomlDate from './custom-toml-date';
import type { CustomTomlTypes, MetaRecord, MetaState, TableRecord } from './toml-types';
import { ObjType } from './toml-enum';
export interface ContentDetailRes {
    startPos: number;
    parsedRes: string;
    sliceStart: number;
    isEscape: boolean;
    tempPosition: number;
}
export declare function parseContent(content: string, startPosParam?: number, endPosParam?: number): string;
export declare function parseValue(value: string, content: string, position: number): boolean | number | CustomTomlDate;
export declare function extractValue(content: string, startPosition: number, endCharacter?: string): [CustomTomlTypes, number];
export interface ParseKeyReq {
    character: string;
    contentStr: string;
    startPos: number;
    dotPos: number;
    endPos: number;
    endCharacter: string;
}
export interface ParseKeyRes {
    dotPos: number;
    endPos: number;
}
export declare function parseKey(contentStr: string, startPosParam: number, endCharacter?: string): [string[], number];
export interface InlineTableRes {
    position: number;
    comma: number;
}
export declare function parseInlineTable(str: string, positionParam: number): [Record<string, CustomTomlTypes>, number];
export declare function parseArray(str: string, positionParam: number): [CustomTomlTypes[], number];
export interface DefinePropertiesReq {
    hasProperty: boolean;
    propertyKey: string;
    i: number;
    keys: string[];
    objType: ObjType;
}
export interface ArrayObjRes {
    state: MetaState;
    table: any;
}
export declare function findTable(keys: string[], tableRecord: Record<string, CustomTomlTypes>, metaRecord: MetaRecord, objType: ObjType): TableRecord;
