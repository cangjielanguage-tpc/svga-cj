/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { ModuleModel } from '@ohos/hvigor-ohos-plugin/src/model/module/module-model';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import type { Module } from '@ohos/hvigor';
import type { AbstractModulePlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/common/abstract-module-plugin';
/**
 * cangjie plugin basic class
 *
 * @since 2024/1/6
 */
export declare class BaseCangjiePlugin {
    protected modulePlugin: AbstractModulePlugin;
    protected _module: Module | undefined;
    protected _moduleModel: ModuleModel | undefined;
    protected _needExecTargetServiceList: TargetTaskService[] | undefined;
    constructor(modulePlugin: AbstractModulePlugin);
    initTasks(): Promise<void>;
    private doAddCangjieTasks;
}
