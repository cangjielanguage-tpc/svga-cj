import { SdkComponent } from './cangjie-sdk-info';
/**
 * cangjie sdk instance
 *
 * @since 2024-01-14
 */
export declare class SdkCangjieComponent {
    private readonly _compilerPath;
    private readonly _toolsBin;
    private readonly _sysResourcePath;
    private readonly _llvmPath;
    private readonly _buildPath;
    private readonly _sdkRoot;
    private readonly _jsLibsLoader;
    private readonly _aarch64OhosLibPath;
    private readonly _aarch64OpensslPath;
    private readonly _aarch64KitPath;
    private readonly _x86OhosLibPath;
    private readonly _x86OpensslPath;
    private readonly _x86KitPath;
    private readonly _macroLibPath;
    private readonly _runtimeLibPath;
    private readonly _aarch64RuntimeOhosLib;
    private readonly _x86RuntimeOhosLib;
    private readonly _aarch64AsanRuntimeOhosLib;
    private readonly _x86AsanRuntimeOhosLib;
    private readonly _aarch64WrapperMockLib;
    private readonly _x86WrapperMockLib;
    private readonly _aarch64WrapperDiffLib;
    private readonly _x86WrapperDiffLib;
    private readonly _aarch64ApiMockLib;
    private readonly _x86ApiMockLib;
    private readonly _aarch64ApiCompatibleLib;
    private readonly _x86ApiCompatibleLib;
    private readonly _aarch64RuntimeCompatibilityLib;
    private readonly _x86RuntimeCompatibilityLib;
    private readonly _aarch64RuntimeMockLib;
    private readonly _x86RuntimeMockLib;
    private readonly _cjcPath;
    constructor(component: SdkComponent);
    get compilerPath(): string;
    get toolsBin(): string;
    get sysResourcePath(): string;
    get llvmPath(): string;
    get buildPath(): string;
    get sdkRoot(): string;
    get jsLibsLoader(): string;
    get runtimeLibPath(): string;
    get aarch64RuntimeOhosLib(): string;
    get x86RuntimeOhosLib(): string;
    get aarch64AsanRuntimeOhosLib(): string;
    get x86AsanRuntimeOhosLib(): string;
    get cjcPath(): string;
    get aarch64OhosLibPath(): string;
    get aarch64KitPath(): string;
    get x86OhosLibPath(): string;
    get x86OpensslPath(): string;
    get x86KitPath(): string;
    get macroLibPath(): string;
    get aarch64OpensslPath(): string;
    get aarch64WrapperMockLib(): string;
    get x86WrapperMockLib(): string;
    get aarch64WrapperDiffLib(): string;
    get x86WrapperDiffLib(): string;
    get aarch64ApiMockLib(): string;
    get x86ApiMockLib(): string;
    get aarch64ApiCompatibleLib(): string;
    get x86ApiCompatibleLib(): string;
    get aarch64RuntimeCompatibilityLib(): string;
    get x86RuntimeCompatibilityLib(): string;
    get aarch64RuntimeMockLib(): string;
    get x86RuntimeMockLib(): string;
    private getRuntimeLib;
}
